<template>
    <section class="content">
        <div class="container-fluid">
            <div class="row ">
            <div class="col-md-12">
                <h2 style="text-align: center;color:red">Welcome to User Role Management system</h2>
                </div>
            </div>
            <!-- /.row -->
        </div><!--/. container-fluid -->
    </section>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
