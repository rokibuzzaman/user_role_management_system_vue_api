<template>
  <section class="content">
    <div class="container-fluid">
        <div class="row">

          <div class="col-12">
        
            <div class="card" v-if="$gate.isAdmin()">
              <div class="card-header">
                <h3 class="card-title">Profile Information</h3>

                <div class="card-tools" v-show="UserProfiles.data==0">
                
                  
                  <button  type="button" class="btn btn-sm btn-primary" @click="newModal">
                      <i class="fa fa-plus-square"></i>
                      Add New
                  </button>
               
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Position</th>
                      <th>Team</th>
                      <th>NID</th>
                      <th>Qualification</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                     <tr v-for="UserProfile in UserProfiles.data" :key="UserProfile.id">

                      <td>{{UserProfile.id}}</td>
                      <td class="text-capitalize">{{UserProfile.fname}}</td>
                      <td class="text-capitalize">{{UserProfile.lname}}</td>
                      <td>{{UserProfile.email}}</td>
                      <td>{{UserProfile.mobile}}</td>
                      <td>{{UserProfile.position}}</td>
                      <td>{{UserProfile.team}}</td>
                      <td>{{UserProfile.nid}}</td>
                      <td>{{UserProfile.qualification}}</td>
                    
                      <td>

                        <a href="#" @click="editModal(UserProfile)">
                            <i class="fa fa-edit blue"></i>
                        </a>
                        <a href="#" @click="deleteUserProfile(UserProfile.id)">
                            <i class="fa fa-trash red"></i>
                        </a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                  <pagination :data="roles" @pagination-change-page="getResults"></pagination>
              </div>
            </div>
            <!-- /.card -->
          </div>
        </div>


        <div v-if="!$gate.isAdmin()">
            <not-found></not-found>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="addNew" tabindex="-1" role="dialog" aria-labelledby="addNew" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" v-show="!editmode">Create New Tag</h5>
                    <h5 class="modal-title" v-show="editmode">Update Tag</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <!-- <form @submit.prevent="createUser"> -->

                <form @submit.prevent="editmode ? updateTag() : createTag()">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>First Name</label>
                            <input v-model="form.fname" type="text" name="fname"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('fname') }">
                            <has-error :form="form" field="fname"></has-error>
                        </div>

                        <div class="form-group">
                            <label>Last Name</label>
                            <input v-model="form.lname" type="text" name="lname"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('lname') }">
                            <has-error :form="form" field="lname"></has-error>
                        </div>

                          <div class="form-group">
                            <label>Email</label>
                            <input v-model="form.email" type="text" name="email"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('email') }">
                            <has-error :form="form" field="email"></has-error>
                        </div>


                         <div class="form-group">
                            <label>Mobile</label>
                            <input v-model="form.mobile" type="text" name="mobile"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('mobile') }">
                            <has-error :form="form" field="mobile"></has-error>
                        </div>


                        <div class="form-group">
                            <label>Position</label>
                            <input v-model="form.position" type="text" name="position"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('position') }">
                            <has-error :form="form" field="position"></has-error>
                        </div>

                        <div class="form-group">
                            <label>Team</label>
                            <input v-model="form.team" type="text" name="team"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('team') }">
                            <has-error :form="form" field="team"></has-error>
                        </div>

                        <div class="form-group">
                            <label>NID</label>
                            <input v-model="form.nid" type="text" name="nid"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('nid') }">
                            <has-error :form="form" field="nid"></has-error>
                        </div>


                        <div class="form-group">
                            <label>Qualification</label>
                            <input v-model="form.qualification" type="text" name="qualification"
                                class="form-control" :class="{ 'is-invalid': form.errors.has('qualification') }">
                            <has-error :form="form" field="qualification"></has-error>
                        </div>

                      
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button v-show="editmode" type="submit" class="btn btn-success">Update</button>
                        <button v-show="!editmode" type="submit" class="btn btn-primary">Create</button>
                    </div>
                  </form>
                </div>
            </div>
        </div>
    </div>
  </section>
</template>

<script>
    export default {
        data () {
            return {
                editmode: false,
                UserProfiles : {},
                form: new Form({
                    id : '',
                    fname: '',
                    lname : '',
                    email : '',
                    mobile : '',
                    position : '',
                    team : '',
                    nid : '',
                    qualification  : '',
                })
            }
        },
        methods: {

            getResults(page = 1) {

                  this.$Progress.start();
                  
                  axios.get('/api/UserProfile?page=' + page).then(({ data }) => (this.UserProfiles = data.data));

                  this.$Progress.finish();
            },
            updateTag(){
                this.$Progress.start();
                // console.log('Editing data');
                this.form.put('/api/UserProfile/'+this.form.id)
                .then((response) => {
                    // success
                    $('#addNew').modal('hide');
                    Toast.fire({
                      icon: 'success',
                      title: response.data.message
                    });
                    this.$Progress.finish();
                        //  Fire.$emit('AfterCreate');

                    this.loadTags();
                })
                .catch(() => {
                    this.$Progress.fail();
                });

            },

              deleteUserProfile(id){
              Swal.fire({
                  title: 'Are you sure?',
                  text: "You won't be able to revert this!",
                  showCancelButton: true,
                  confirmButtonColor: '#d33',
                  cancelButtonColor: '#3085d6',
                  confirmButtonText: 'Yes, delete it!'
                  }).then((result) => {

                      // Send request to the server
                        if (result.value) {
                              this.form.delete('api/UserProfile/'+id).then(()=>{
                                      Swal.fire(
                                      'Deleted!',
                                      'Your file has been deleted.',
                                      'success'
                                      );
                                  // Fire.$emit('AfterCreate');
                                  this.loadTags();
                              }).catch((data)=> {
                                  Swal.fire("Failed!", data.message, "warning");
                              });
                        }
                  })
          },
            editModal(UserProfile){
                this.editmode = true;
                this.form.reset();
                $('#addNew').modal('show');
                this.form.fill(UserProfile);
            },
            newModal(){
                this.editmode = false;
                this.form.reset();
                $('#addNew').modal('show');
            },

            loadTags(){
                if(this.$gate.isAdmin()){
                    axios.get("/api/UserProfile").then(({ data }) => (this.UserProfiles = data.data));
                }
            },
            
            createTag(){

                this.form.post('/api/UserProfile')
                .then((response)=>{
                    $('#addNew').modal('hide');

                    Toast.fire({
                            icon: 'success',
                            title: response.data.message
                    });

                    this.$Progress.finish();
                    this.loadTags();

                })
                .catch(()=>{

                    Toast.fire({
                        icon: 'error',
                        title: 'Some error occured! Please try again'
                    });
                })
            }

        },
        mounted() {
            console.log('Component mounted.')
        },
        created() {

            this.$Progress.start();
            this.loadTags();
            this.$Progress.finish();
        }
    }
</script>
