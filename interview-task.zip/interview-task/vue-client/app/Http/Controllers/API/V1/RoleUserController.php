<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Requests\Products\ProductRequest;
use App\Models\Product;
use App\Models\Tag;
use App\Models\RoleUser;
use Illuminate\Http\Request;

class RoleUserController extends BaseController
{

    protected $RoleUser = '';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(RoleUser $RoleUser)
    {
        $this->middleware('auth:api');
        $this->RoleUser = $RoleUser;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $RoleUsers = $this->RoleUser->latest()->with('user', 'role')->paginate(10);

        return $this->sendResponse($RoleUsers, 'Role Assign list');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  App\Http\Requests\Products\ProductRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $RoleUser = $this->RoleUser->create([
            
            'user_id' => $request->get('user_id'),
            'role_id' => $request->get('role_id'),
        ]);

      
        return $this->sendResponse($RoleUser, 'Role Assign Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $product = $this->product->with(['category', 'tags'])->findOrFail($id);

        return $this->sendResponse($product, 'Product Details');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $RoleUser = $this->RoleUser->findOrFail($id);

        $RoleUser->update($request->all());

       

        return $this->sendResponse($RoleUser, 'Role Assign has been updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $this->authorize('isAdmin');

        $RoleUser = $this->RoleUser->findOrFail($id);

        $RoleUser->delete();

        return $this->sendResponse($RoleUser, 'Role Assign has been Deleted');
    }

 
}
