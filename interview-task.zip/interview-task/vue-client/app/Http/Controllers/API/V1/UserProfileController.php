<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\UserProfile;
use Illuminate\Http\Request;

class UserProfileController extends BaseController
{
    protected $UserProfile = '';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserProfile $UserProfile)
    {
        $this->middleware('auth:api');
        $this->UserProfile = $UserProfile;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $UserProfiles = $this->UserProfile->latest()->paginate(10);

        return $this->sendResponse($UserProfiles, 'Profile Information');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function list()
    {
        $UserProfiles = $this->UserProfile->get(['name', 'id']);

        return $this->sendResponse($UserProfiles, 'Profile Information');
    }



      public function listdata()
    {
        $roles = $this->role->pluck('name', 'id');

        return $this->sendResponse($roles, 'Roles list');
    }


    /**
     * Store a newly created resource in storage.
     *
     *
     * @param $id
     *
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        //dd('ddfdf');
        //dd($request->all());
        $UserProfile = $this->UserProfile->create([
            'fname' => $request->get('fname'),
            'lname' => $request->get('lname'),
            'email' => $request->get('email'),
            'mobile' => $request->get('mobile'),
            'position' => $request->get('position'),
            'team' => $request->get('team'),
            'nid' => $request->get('nid'),
            'qualification' => $request->get('qualification')
        ]);

        return $this->sendResponse($UserProfile, 'UserProfile Created Successfully');
    }

    /**
     * Update the resource in storage
     *
     * @param $id
     *
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        $UserProfile = $this->UserProfile->findOrFail($id);

        $UserProfile->update($request->all());

        return $this->sendResponse($UserProfile, 'User Profile Information has been updated');
    }


     public function destroy($id)
    {

        $this->authorize('isAdmin');

        $UserProfile = $this->UserProfile->findOrFail($id);

        $UserProfile->delete();

        return $this->sendResponse($UserProfile, 'UserProfile has been Deleted');
    }

}
