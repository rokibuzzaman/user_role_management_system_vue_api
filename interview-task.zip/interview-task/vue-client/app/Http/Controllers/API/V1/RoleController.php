<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\Role;
use Illuminate\Http\Request;

class RoleController extends BaseController
{
    protected $role = '';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Role $role)
    {
        $this->middleware('auth:api');
        $this->role = $role;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $roles = $this->role->latest()->paginate(10);

        return $this->sendResponse($roles, 'Role list');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function list()
    {
        $roles = $this->role->get(['name', 'id']);

        return $this->sendResponse($roles, 'Roles list');
    }



      public function listdata()
    {
        $roles = $this->role->pluck('name', 'id');

        return $this->sendResponse($roles, 'Roles list');
    }


    /**
     * Store a newly created resource in storage.
     *
     *
     * @param $id
     *
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        //dd('ddfdf');
        //dd($request->all());
        $role = $this->role->create([
            'name' => $request->get('name'),
            'description' => $request->get('description')
        ]);

        return $this->sendResponse($role, 'Role Created Successfully');
    }

    /**
     * Update the resource in storage
     *
     * @param $id
     *
     * @return \Illuminate\Http\Response
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id)
    {
        $role = $this->role->findOrFail($id);

        $role->update($request->all());

        return $this->sendResponse($role, 'Role Information has been updated');
    }


     public function destroy($id)
    {

        $this->authorize('isAdmin');

        $role = $this->role->findOrFail($id);

        $role->delete();

        return $this->sendResponse($role, 'Role has been Deleted');
    }

}
