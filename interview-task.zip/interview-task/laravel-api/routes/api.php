<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



Route::namespace('Api')->group(function () {
    //user registration
    Route::post('/register', 'AuthController@register');

    //user login
    Route::post('/login', 'AuthController@login');

    //user role
    Route::post('/role', 'RoleController@saveRole');


    //user role assign
    Route::post('/roleuser', 'RoleUserController@saveRoleUser');
    Route::delete('RoleUser/{RoleUser}', 'RoleUserController@deleteRoleUser');
    //user List

    Route::get('userlist', 'AuthController@showUserList');
    Route::get('profilelist', 'AuthController@showProfileList');


    //Task assign
    Route::post('/task', 'TaskController@saveTask');

    //Task update
    Route::put('/task/{task_id}', 'TaskController@updateTask');

    Route::get('/task/list', 'TaskController@showTaskList');


});
