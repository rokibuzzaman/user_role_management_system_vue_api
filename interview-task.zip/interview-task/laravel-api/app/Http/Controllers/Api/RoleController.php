<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Role;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class RoleController extends Controller
{

    public function saveRole(Request $request)
    {

        
        $title = $request->title;

        $data = $request->all();
        $validator = Validator::make($data, [
     
            'title' => 'required'
          
        ]);

        if ($validator->fails()) {
            return response(['message'=>'Invalid Data', 'error'=>$validator->errors()],400);
        }

        $role = Role::create($data);

        if(isset($role)){
            return response(['role' => $role], 201);
        }else{
            return response(['message'=>'Server Internal Error'], 500);
        }
    }




}
