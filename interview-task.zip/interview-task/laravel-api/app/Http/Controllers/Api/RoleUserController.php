<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\RoleUser;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class RoleUserController extends Controller
{

    public function saveRoleUser(Request $request)
    {

        
        $user_id = $request->user_id;
        $role_id = $request->role_id;

        $data = $request->all();
        $validator = Validator::make($data, [
     
            'user_id' => 'required',
            'role_id' => 'required'
          
        ]);

        if ($validator->fails()) {
            return response(['message'=>'Invalid Data', 'error'=>$validator->errors()],400);
        }

        $role_user = RoleUser::insert($data);

        if(isset($role_user)){
            return response(['role_user' => $role_user], 201);
        }else{
            return response(['message'=>'Server Internal Error'], 500);
        }
    }


     public function deleteRoleUser(Request $request,RoleUser $RoleUser)
    {
         $RoleUser->delete();
         return response()->json(null,204);

        
    }




}
